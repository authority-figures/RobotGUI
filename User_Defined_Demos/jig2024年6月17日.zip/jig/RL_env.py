import time

import gym
from gym import spaces
import pybullet as p
import pybullet_data
import numpy as np
import cv2
import os

class RobotArmEnv(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self):
        super(RobotArmEnv, self).__init__()

        # 初始化 PyBullet
        self.client_id = p.connect(p.GUI)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())

        # 定义动作空间和观测空间
        self.action_space = spaces.Box(low=np.array([-1, -1, -1, -1]), high=np.array([1, 1, 1, 1]), dtype=np.float32)
        self.observation_space = spaces.Box(low=0, high=255, shape=(240, 320, 1), dtype=np.uint8)

        # 加载机械臂模型
        self.robot_id = p.loadURDF("kuka_iiwa/model.urdf", useFixedBase=True)

        # 设置摄像头参数
        self.camera_distance = 1.5
        self.camera_pitch = -40
        self.camera_yaw = 180
        self.camera_target_pos = (0.5, 0, 0)

    def reset(self):
        p.resetSimulation()
        p.setGravity(0, 0, -10)
        self.robot_id = p.loadURDF("kuka_iiwa/model.urdf", useFixedBase=True)
        return self.get_observation()

    def step(self, action):
        # 应用动作到机械臂
        p.setJointMotorControlArray(self.robot_id, range(4), p.POSITION_CONTROL, targetPositions=action)

        p.stepSimulation()
        time.sleep(1/240)

        # 获取新的观测
        observation = self.get_observation()
        reward = self.calculate_reward()
        done = self.check_if_done()

        return observation, reward, done, {}

    def get_observation(self):
        # 获取摄像头图像作为观测
        view_matrix = p.computeViewMatrixFromYawPitchRoll(cameraTargetPosition=self.camera_target_pos,
                                                          distance=self.camera_distance,
                                                          yaw=self.camera_yaw,
                                                          pitch=self.camera_pitch,
                                                          roll=0,
                                                          upAxisIndex=2)
        proj_matrix = p.computeProjectionMatrixFOV(fov=60, aspect=float(320) / 240, nearVal=0.1, farVal=100.0)
        _, _, _, depth_buffer ,_= p.getCameraImage(width=320, height=240, viewMatrix=view_matrix, projectionMatrix=proj_matrix)

        depth = np.array(depth_buffer).reshape((240, 320, 1))
        depth = (depth * 255).astype(np.uint8)  # 归一化到 0-255

        return depth

    def render(self, mode='human'):
        pass

    def close(self):
        p.disconnect()

    def calculate_reward(self):
        # 计算奖励
        return 0

    def check_if_done(self):
        # 检查任务是否完成
        return False


if __name__ == '__main__':

    env = RobotArmEnv()
    observation = env.reset()
    for _ in range(100):
        action = env.action_space.sample()  # 随机选择一个动作
        observation, reward, done, info = env.step(action)
        if done:
            observation = env.reset()
    env.close()
