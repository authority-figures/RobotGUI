import time
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ''))
import numpy as np
import pybullet as p
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ''))
import functools
from utils import *
from Environment.PybulletEnv import PybulletEnv
from RobotDir.Robot import Robot
from RobotDir.Machine import Machine
from RobotDir.Gripper import Gripper
import pybullet_data
from RobotDir.Camera import Camera

import threading


def record_time(func):
    """Decorator to record the execution time of a function."""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"{func.__name__} executed in {elapsed_time:.4f} seconds.")
        return result

    return wrapper

class Command:

    _id_counter = 0  # 类变量，用于自动生成命令ID
    def __init__(self, type, parallel=False,id=None,parallel_id=0,wait_time=0,**kwargs):
        self.type = type
        self.data = kwargs
        self.parallel = parallel
        self.wait_time = wait_time
        self.generator = None
        self.completed = False
        self.id = id if id is not None else Command._id_counter
        self.parallel_id = parallel_id
        Command._id_counter += 1
        self.start_time = None  # 开始时间
        self.end_time = None  # 结束时间


    def execute(self, sys):
        """ Execute the command within the given environment as a coroutine. """
        if not self.generator:
            self.start_time = time.time()  # 记录开始时间
            # Decide which generator to use based on command type
            if self.type == "move_arm":
                self.generator = self.move_arm(sys, **self.data)
            elif self.type == "close_gripper":
                self.generator = self.close_gripper(sys)
            elif self.type == "open_gripper":
                self.generator = self.open_gripper(sys)
            elif self.type == 'wait':
                self.generator = self.wait(**self.data)

        try:
            next(self.generator)
        except StopIteration:
            self.completed = True
            self.end_time = time.time()  # 记录结束时间
            self.print_execution_time()  # 打印执行时间

    def print_execution_time(self):
        """ Print the execution time of the command. """
        if self.start_time and self.end_time:
            elapsed_time = self.end_time - self.start_time
            print(f"Command {self.type} ID {self.id} executed in {elapsed_time:.4f} seconds.")

    def move_arm(self, sys, **data):
        """ A generator to simulate the movement of an arm over multiple simulation steps. """
        # Simulate a gradual movement by breaking it into steps
        positions = data.get('positions',[[0,0,0],[0,0,0,1]])
        scale = data.get('scale', 30)
        KP = data.get('KP', 0.1)
        KD = data.get('KD', 0.3)
        robot_target_pos, robot_target_ori = positions[0],positions[1]
        joints = sys.env.robots[0].calc_path_joints(None, None, robot_target_pos, robot_target_ori)
        inter_joints = sys.env.robots[0].interpolation_path(joints, scale=scale)
        # # 创建一个持续的生成器实例
        # joint_generator = sys.env.robots[0].run_joints_lists(inter_joints, sys.env.robots[0].id_robot,
        #                                                      sleep_time=1 / 240., KP=0.1, targetVelocity=0)


        for joints in inter_joints:
            for i, joint_position in enumerate(joints):
                p.setJointMotorControl2( sys.env.robots[0].id_robot, i, p.POSITION_CONTROL, targetPosition=joint_position,
                                        targetVelocity=0.0,
                                        positionGain=KP,  # KP
                                        velocityGain=KD,  # KD
                                        force=1000,
                                        )

            yield 0
        return 1

        # while True:
        #     try:
        #         completed = next(joint_generator)
        #     except StopIteration:
        #         completed = True
        #
        #     if completed:
        #         break
        #     yield  # Yield control and wait for the next call

    def close_gripper(self, sys):
        """ A generator for closing the gripper, simulated over multiple steps. """

        sys.gp.close('useVelocity', targetVelocity=0.3, force=100)
        yield  # Simulate the gripper takes time to close
        # yield  # Continue simulating if needed

    def open_gripper(self, sys):
        """ A generator for closing the gripper, simulated over multiple steps. """

        sys.gp.open('useVelocity', targetVelocity=0.3, force=100)
        yield

    def wait(self,**data):
        sleep_time = data.get('sleep_time',5)
        start_time = time.time()
        while True:
            current_time = time.time()
            if current_time-start_time>=sleep_time:
                break
            yield
        pass


class Controller:

    def __init__(self):
        self.command_queue = []
        self.active_commands = []
        self.this_command = Command('None',)
        self.this_command.completed = True


    def add_command(self, command):
        if command.parallel:
            self.active_commands.append(command)
        else:
            self.command_queue.append(command)

    def execute_commands(self, env):


        # Process the queue if no non-parallel commands are active
        # if not self.active_commands:
        if self.command_queue and self.this_command.completed:
            self.this_command = self.command_queue.pop(0)
            self.this_command.start_time = time.time()

        if not self.this_command.completed:
            self.this_command.execute(env)
        elif self.this_command.type != 'None':
            print(f"Command {self.this_command.type} completed, id:{self.this_command.id}.")
            self.this_command = Command('None',)
            self.this_command.completed = True
        # self.command_queue = [cmd for cmd in self.command_queue if not cmd.completed]


        # Execute all parallel commands
        current_time = time.time()
        current_parallel_id = self.this_command.id
        for command in self.active_commands:
            if not command.completed and (command.parallel_id == current_parallel_id or command.parallel_id==0):
                # 判断并行任务的等待时间
                if current_time - self.this_command.start_time >= command.wait_time and self.this_command.type != 'None':
                    command.execute(env)

        # Clean up completed parallel commands
        self.active_commands = [cmd for cmd in self.active_commands if not cmd.completed]





