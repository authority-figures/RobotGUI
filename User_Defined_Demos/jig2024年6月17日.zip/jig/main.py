import time
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ''))
import numpy as np
import pybullet as p
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ''))
import functools
from utils import *
from Environment.PybulletEnv import PybulletEnv
from RobotDir.Robot import Robot
from RobotDir.Machine import Machine
from RobotDir.Gripper import Gripper
import pybullet_data
from RobotDir.Camera import Camera
from combined_sys import GraspSystem
import threading
from Controller import Controller,Command
from multiprocessing import Process,Queue
# def run_controller(system):
#     while system.running:
#         system.controller.execute_commands(system)
#         system.update_cam_pos()
#         if system.RGB_camera.img_data:
#             system.RGB_camera.display_depth_image(system.RGB_camera.img_data, 0, 1)
#         system.sys_update()


def main():
    controller = Controller()
    grasp_system = GraspSystem()
    grasp_system.reset_cam_fps(30)
    grasp_system.create_box()
    grasp_system.controller = controller

    # Add commands
    grasp_system.controller.add_command(Command('open_gripper', parallel=False, ))
    grasp_system.controller.add_command(Command('move_arm', parallel=False, positions=[[-0.5, -0.3, 0.139], [0, 0, 0, 1]], scale=10))
    grasp_system.controller.add_command(Command('close_gripper', parallel=False, parallel_id=2))
    grasp_system.controller.add_command(Command('wait', parallel=False, sleep_time=5))
    grasp_system.controller.add_command(Command('move_arm', parallel=False, positions=[[-0, -0, 0.5], [0, 0, 0, 1]], scale=30))
    grasp_system.controller.add_command(Command('open_gripper', parallel=False, parallel_id=5, wait_time=3))
    grasp_system.run()
    pass

def test_thread():
    grasp_system = GraspSystem()
    grasp_system.reset_cam_fps(30)
    grasp_system.create_box()

    # 开始仿真在一个新线程
    thread = threading.Thread(target=run_controller, args=(grasp_system,))
    thread.start()

    # 在主线程中添加命令

    grasp_system.controller.add_command(Command('open_gripper', parallel=False, ))
    grasp_system.controller.add_command(Command('move_arm', parallel=False, positions=[[-0.5, -0.3, 0.139], [0, 0, 0, 1]], scale=10))
    grasp_system.controller.add_command(Command('close_gripper', parallel=False, parallel_id=2))
    grasp_system.controller.add_command(Command('wait', parallel=False, sleep_time=5))
    grasp_system.controller.add_command(Command('move_arm', parallel=False, positions=[[-0, -0, 0.5], [0, 0, 0, 1]], scale=30))
    grasp_system.controller.add_command(Command('open_gripper', parallel=False, parallel_id=5, wait_time=3))

    # 当需要停止时
    # grasp_system.running = False
    thread.join()  # 等待线程完成

    pass
def run_controller(grasp_system):

    grasp_system.run()
    # p.disconnect(grasp_system.connection_id)

def add_commands_to_queue(command_queue):
    command_queue.put(Command('open_gripper'))
    command_queue.put(Command('move_arm', positions=[[-0.5, -0.3, 0.139], [0, 0, 0, 1]], scale=10))
    command_queue.put(Command('close_gripper', parallel_id=2))
    command_queue.put(Command('wait', sleep_time=5))
    command_queue.put(Command('move_arm', positions=[[-0, -0, 0.5], [0, 0, 0, 1]], scale=30))
    command_queue.put(Command('open_gripper', parallel_id=5, wait_time=3))

def test_multiprocessing():
    command_queue = Queue()
    grasp_system = GraspSystem()
    grasp_system.controller.command_queue = command_queue
    process = Process(target=run_controller, args=(grasp_system,))
    process.start()

    add_commands_to_queue(command_queue)  # 在主线程中添加命令

    process.join()  # 等待进程完成

if __name__ == '__main__':
    main()
    # test_thread()

    # test_multiprocessing()

    pass